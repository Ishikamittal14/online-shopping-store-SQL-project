-- Sample insertion for customers
INSERT INTO Customers (name, email, password, phone, address)
VALUES
('Nick Liester', 'nick.liester@example.com', 'hashqdpass001', '1357923455', 'London, UK'),
('Simran Kaur', 'simran.kaur@example.com', 'hashedpass002', '9123456781', 'Mumbai, India'),
('John Smith', 'john.smith@example.com', 'hashedpass003', '9877001122', 'New York, USA'),
('Emily Johnson', 'emily.johnson@example.com', 'hashedpass004', '9988112233', 'London, UK'),
('Karan Malhotra', 'karan.malhotra@example.com', 'hashedpass005', '9876223344', 'Pune, India'),
('Olivia Brown', 'olivia.brown@example.com', 'hashedpass006', '9876334455', 'Sydney, Australia'),
('Vivek Rao', 'vivek.rao@example.com', 'hashedpass007', '9876445566', 'Ahmedabad, India'),
('Sofia Garcia', 'sofia.garcia@example.com', 'hashedpass008', '9876556677', 'Madrid, Spain'),
('Lucas Martin', 'lucas.martin@example.com', 'hashedpass009', '9876667788', 'Toronto, Canada'),
('Ananya Singh', 'ananya.singh@example.com', 'hashedpass010', '9876778899', 'Bangalore, India');

SELECT * FROM Customers;

-- Sample insertion for products
INSERT INTO Products (name, description, price, stock_quantity, category)
VALUES
('Smartphone', 'Latest Android smartphone with high performance', 20000.00, 50, 'Electronics'),
('Laptop', 'High performance laptop for gaming and work', 55000.00, 30, 'Electronics'),
('Washing Machine', 'Fully automatic front load washing machine', 15000.00, 20, 'Home Appliances'),
('Refrigerator', 'Double door refrigerator with energy saving mode', 25000.00, 15, 'Home Appliances'),
('Headphones', 'Wireless noise-cancelling headphones', 3000.00, 100, 'Electronics'),
('Microwave Oven', 'Compact microwave oven for quick heating', 5000.00, 25, 'Home Appliances'),
('T-Shirt', 'Cotton casual T-Shirt for men, multiple colors', 499.00, 200, 'Clothing'),
('Jeans', 'Blue denim jeans for men, slim fit', 1499.00, 150, 'Clothing'),
('Air Conditioner', '1.5 Ton split AC with inverter technology', 30000.00, 10, 'Home Appliances'),
('Electric Kettle', '1.5-liter electric kettle with auto shut-off', 2000.00, 80, 'Home Appliances');

SELECT * FROM Products;

-- Sample insertion for orders
INSERT INTO Orders (customer_id, order_id, total_amount, order_date)
VALUES
(1, 1, 20000.00, '2025-09-12 10:00:00'),
(2, 7, 1497.00, '2025-09-11 15:30:00'),
(3, 2, 55000.00, '2025-09-10 09:15:00'),
(4, 8, 2998.00, '2025-09-09 18:45:00'),
(5, 3, 15000.00, '2025-09-08 11:20:00'),
(6, 9, 30000.00, '2025-09-07 14:50:00'),
(7, 4, 25000.00, '2025-09-06 13:05:00'),
(8, 5, 6000.00, '2025-09-05 16:30:00'),
(9, 6, 5000.00, '2025-09-04 12:40:00'),
(10, 10, 2000.00, '2025-09-03 10:10:00');

SELECT * FROM Orders;


-- Sample insertion for cart_items
INSERT INTO Cart_Items (cart_item_id,  product_id, quantity)
VALUES
(1, 1, 1),
(2, 7, 2),
(3, 3, 1),
(4, 8, 3),
(5, 4, 1),
(6, 5, 2),
(7, 6, 1),
(8, 9, 1),
(9, 10, 2),
(10, 2, 1);

SELECT * FROM cart_items;

-- Sample insertion for order_items
INSERT INTO Order_Items (order_id, product_id, quantity, price)
VALUES
(1, 1, 1, 20000.00),
(2, 7, 3, 1497.00),
(3, 2, 1, 55000.00),
(4, 8, 2, 2998.00),
(5, 3, 1, 15000.00),
(6, 9, 1, 30000.00),
(7, 4, 1, 25000.00),
(8, 5, 2, 6000.00),
(9, 6, 1, 5000.00),
(10, 10, 1, 2000.00);

SELECT * FROM order_items;

-- Sample insertion for payments
INSERT INTO Payments (order_id, payment_date, payment_method, amount_paid, payment_status)
VALUES
(1, '2025-09-12 10:10:00', 'Credit Card', 20000.00, 'Completed'),
(2, '2025-09-11 15:45:00', 'Debit Card', 1497.00, 'Completed'),
(3, '2025-09-10 09:30:00', 'Net Banking', 55000.00, 'Completed'),
(4, '2025-09-09 19:00:00', 'UPI', 2998.00, 'Completed'),
(5, '2025-09-08 11:45:00', 'Credit Card', 15000.00, 'Completed'),
(6, '2025-09-07 15:05:00', 'Debit Card', 30000.00, 'Completed'),
(7, '2025-09-06 13:20:00', 'UPI', 25000.00, 'Completed'),
(8, '2025-09-05 16:50:00', 'Credit Card', 6000.00, 'Completed'),
(9, '2025-09-04 12:50:00', 'Net Banking', 5000.00, 'Completed'),
(10, '2025-09-03 10:20:00', 'UPI', 2000.00, 'Completed');

SELECT * FROM payments;
