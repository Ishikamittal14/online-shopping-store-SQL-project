-- Sample Queries

-- Get all products in a customer's cart
SELECT p.name, oi.quantity, p.price
FROM Order_Items oi
JOIN Products p ON oi.product_id = p.product_id
WHERE oi.order_id = 1;

-- Get order details and payment status
SELECT o.order_id, o.order_date, o.total_amount, o.status, p.payment_method, p.payment_status
FROM Orders o
LEFT JOIN Payments p ON o.order_id = p.order_id
WHERE o.customer_id = 1;

-- Get total revenue generated
SELECT SUM(amount_paid) AS total_revenue
FROM Payments
WHERE payment_status = 'Completed';

-- Trigger to update stock quantity after an order item is inserted
DELIMITER $$
CREATE TRIGGER update_stock AFTER INSERT ON Order_Items
FOR EACH ROW
BEGIN
    UPDATE Products
    SET stock_quantity = stock_quantity - NEW.quantity
    WHERE product_id = NEW.product_id;
END$$
DELIMITER ;

SELECT p.name AS product_name, SUM(oi.quantity) AS total_quantity_ordered
FROM Order_Items oi
JOIN Products p ON oi.product_id = p.product_id
GROUP BY p.name;

SELECT o.customer_id, SUM(p.amount_paid) AS total_amount_paid
FROM Payments p
LEFT JOIN Orders o ON p.order_id = o.order_id
GROUP BY o.customer_id;



SELECT * FROM Payments WHERE order_id = 1;
SELECT * FROM Orders WHERE customer_id = 1;


